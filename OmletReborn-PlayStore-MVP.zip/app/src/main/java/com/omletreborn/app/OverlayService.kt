package com.omletreborn.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 240 }
    }

    private fun showBubble() {
        val button = Button(this).apply {
            text = "OR"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF218BFF.toInt())
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = button
        windowManager.addView(button, params(120, 64))
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(0xFF111A30.toInt())
        }
        val title = TextView(this).apply {
            text = "Omlet Reborn • Minecraft"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        }
        box.addView(title)
        listOf("Survival 1 • DEMO", "Xây dựng • DEMO", "Parkour • DEMO").forEach { name ->
            box.addView(TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(0xFF45D7FF.toInt())
                setPadding(0, 18, 0, 18)
            })
        }
        box.addView(Button(this).apply {
            text = "Đóng"
            setOnClickListener { hidePanel() }
        })
        panel = box
        windowManager.addView(box, params(300, WindowManager.LayoutParams.WRAP_CONTENT))
    }

    private fun hidePanel() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
