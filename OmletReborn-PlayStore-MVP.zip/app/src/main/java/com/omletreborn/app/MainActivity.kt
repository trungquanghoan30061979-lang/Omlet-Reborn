package com.omletreborn.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF070B18)
private val Panel = Color(0xFF111A30)
private val Blue = Color(0xFF218BFF)
private val Cyan = Color(0xFF45D7FF)
private val Muted = Color(0xFF9DAFCB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmletApp(
            onEnableOverlay = { enableOverlay() },
            onStartOverlay = { startOverlay() }
        ) }
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
        }
    }

    private fun startOverlay() {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java))
        } else enableOverlay()
    }
}

@Composable
private fun OmletApp(onEnableOverlay: () -> Unit, onStartOverlay: () -> Unit) {
    var screen by remember { mutableStateOf("welcome") }
    var user by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var loginAttempts by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableStateOf("Home") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue, secondary = Cyan
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            when (screen) {
                "welcome", "login", "register" -> {
                    Column(
                        modifier = Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color(0xFF10294D), Navy, Navy))
                        ).padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier.size(76.dp).background(
                                Brush.linearGradient(listOf(Blue, Cyan)), RoundedCornerShape(24.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.SportsEsports, null, tint = Color.White, modifier = Modifier.size(42.dp)) }
                        Spacer(Modifier.height(18.dp))
                        Text("OMLET REBORN", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("Play together. Share the moment.", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(36.dp))
                        if (screen == "welcome") {
                            PrimaryButton("Đăng nhập") { screen = "login"; error = "" }
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = { screen = "register"; error = "" },
                                modifier = Modifier.fillMaxWidth().height(52.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Tạo tài khoản", color = Color.White) }
                            Spacer(Modifier.height(12.dp))
                            Text("Bản thử nghiệm • chưa có máy chủ tài khoản", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(18.dp))
                            TextButton(onClick = { screen = "main" }) {
                                Text("Xem thử giao diện chính", color = Cyan)
                            }
                        } else {
                            Text(if (screen == "login") "Chào mừng trở lại" else "Tạo tài khoản", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(20.dp))
                            OutlinedTextField(
                                value = user, onValueChange = { user = it },
                                label = { Text("Tên người dùng") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = password, onValueChange = { password = it },
                                label = { Text("Mật khẩu") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (screen == "register") {
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = confirm, onValueChange = { confirm = it },
                                    label = { Text("Nhập lại mật khẩu") }, singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (error.isNotBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(error, color = Color(0xFFFF7777), fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(18.dp))
                            PrimaryButton(if (screen == "login") "Đăng nhập" else "Đăng ký") {
                                if (user.isBlank() || password.length < 6) {
                                    error = "Nhập tên và mật khẩu tối thiểu 6 ký tự."
                                } else if (screen == "register" && password != confirm) {
                                    error = "Mật khẩu nhập lại chưa khớp."
                                } else if (screen == "login") {
                                    loginAttempts++
                                    error = "Chưa có hệ thống tài khoản thật. Hãy dùng chế độ xem thử."
                                    if (loginAttempts >= 5) error = "Đã thử 5 lần. Đây là bản demo chưa kết nối máy chủ."
                                } else {
                                    error = "Đăng ký trực tuyến chưa bật trong bản demo."
                                }
                            }
                            TextButton(onClick = { screen = "welcome"; error = "" }) {
                                Text("Quay lại", color = Cyan)
                            }
                        }
                    }
                }
                else -> MainMenu(
                    selectedTab = selectedTab,
                    onTab = { selectedTab = it },
                    onEnableOverlay = onEnableOverlay,
                    onStartOverlay = onStartOverlay
                )
            }
        }
    }
}

@Composable
private fun MainMenu(
    selectedTab: String,
    onTab: (String) -> Unit,
    onEnableOverlay: () -> Unit,
    onStartOverlay: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Navy)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("OMLET REBORN", color = Color.White, fontWeight = FontWeight.Black, fontSize = 21.sp)
                Text("Cộng đồng game thủ", color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.NotificationsNone, null, tint = Cyan, modifier = Modifier.size(28.dp))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MenuTile("Minecraft", "Tìm phòng chơi", Icons.Default.SportsEsports, Modifier.weight(1f))
            MenuTile("Bạn bè", "Kết nối cộng đồng", Icons.Default.People, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MenuTile("Livestream", "Sắp ra mắt", Icons.Default.LiveTv, Modifier.weight(1f))
            MenuTile("Tin nhắn", "Chat bạn bè", Icons.Default.ChatBubbleOutline, Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Phòng Minecraft", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("DEMO", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(5) { i ->
                RoomCard("Survival ${i + 1}", listOf("Sinh tồn • 2/8 người", "Xây dựng • 4/10 người", "Parkour • 1/6 người")[i % 3])
            }
            item {
                Spacer(Modifier.height(4.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Cửa sổ nổi", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Bật quyền hiển thị trên ứng dụng khác để thử nút nổi.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onEnableOverlay) { Text("Cấp quyền") }
                            OutlinedButton(onClick = onStartOverlay) { Text("Bật nút nổi") }
                        }
                    }
                }
            }
        }
        NavigationBar(containerColor = Color(0xFF0D1426)) {
            listOf("Home", "Minecraft", "Chat", "Profile").forEach { tab ->
                NavigationBarItem(
                    selected = selectedTab == tab,
                    onClick = { onTab(tab) },
                    icon = {
                        Icon(when (tab) {
                            "Minecraft" -> Icons.Default.SportsEsports
                            "Chat" -> Icons.Default.Chat
                            "Profile" -> Icons.Default.Person
                            else -> Icons.Default.Home
                        }, null)
                    },
                    label = { Text(tab) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Cyan, selectedTextColor = Cyan,
                        indicatorColor = Color(0xFF17345B), unselectedIconColor = Muted,
                        unselectedTextColor = Muted
                    )
                )
            }
        }
    }
}

@Composable
private fun MenuTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier.height(100.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(24.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun RoomCard(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Color(0xFF183C69), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Public, null, tint = Cyan)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Text("Xem", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Blue)
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold) }
}
