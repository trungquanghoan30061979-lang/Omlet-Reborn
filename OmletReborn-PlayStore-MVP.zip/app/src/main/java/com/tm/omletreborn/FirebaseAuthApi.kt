package com.tm.omletreborn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Firebase Authentication REST API. Firebase handles password hashing and account storage. */
object FirebaseAuthApi {
    data class Result(val ok: Boolean, val message: String, val idToken: String? = null, val email: String? = null)

    suspend fun register(email: String, password: String): Result = request("accounts:signUp", email, password)
    suspend fun login(email: String, password: String): Result = request("accounts:signInWithPassword", email, password)

    private suspend fun request(method: String, email: String, password: String): Result = withContext(Dispatchers.IO) {
        val key = BuildConfig.FIREBASE_API_KEY
        if (key == "REPLACE_WITH_FIREBASE_WEB_API_KEY" || key.isBlank())
            return@withContext Result(false, "Chưa cấu hình Firebase API key. Xem README để thiết lập tài khoản online.")
        try {
            val url = URL("https://identitytoolkit.googleapis.com/v1/$method?key=$key")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 15000
                doOutput = true; setRequestProperty("Content-Type", "application/json")
            }
            val body = JSONObject().put("email", email.trim()).put("password", password).put("returnSecureToken", true).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val json = stream.bufferedReader().use { JSONObject(it.readText()) }
            conn.disconnect()
            if (json.has("idToken")) Result(true, "Thành công", json.optString("idToken"), json.optString("email", email))
            else {
                val code = json.optJSONObject("error")?.optString("message", "UNKNOWN_ERROR") ?: "UNKNOWN_ERROR"
                val msg = when {
                    code.contains("EMAIL_EXISTS") -> "Email này đã được đăng ký rồi."
                    code.contains("INVALID_LOGIN_CREDENTIALS") || code.contains("INVALID_PASSWORD") || code.contains("EMAIL_NOT_FOUND") -> "Email hoặc mật khẩu không đúng."
                    code.contains("WEAK_PASSWORD") -> "Mật khẩu phải có ít nhất 6 ký tự."
                    code.contains("INVALID_EMAIL") -> "Email không hợp lệ."
                    code.contains("OPERATION_NOT_ALLOWED") -> "Hãy bật Email/Password trong Firebase Console."
                    else -> "Firebase báo lỗi: $code"
                }
                Result(false, msg)
            }
        } catch (e: Exception) { Result(false, "Không kết nối được. Kiểm tra Internet và cấu hình Firebase.") }
    }
}
