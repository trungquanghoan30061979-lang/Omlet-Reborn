package com.tm.omletreborn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import android.content.Context
import kotlinx.coroutines.launch

private val Ink = Color(0xFF10121B)
private val Panel = Color(0xFF1B1F2D)
private val Orange = Color(0xFFFF7A36)
private val Muted = Color(0xFFA8AEC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AuthGate { OmletApp() } }
    }
}


@Composable
fun AuthGate(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("omlet_session", Context.MODE_PRIVATE) }
    var signedIn by remember { mutableStateOf(prefs.getString("email", null) != null) }
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    if (signedIn) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Đã đăng nhập: ${prefs.getString("email", "")}", Modifier.weight(1f), color = Color.White, fontSize = 12.sp)
                TextButton(onClick = { prefs.edit().clear().apply(); signedIn = false }) { Text("Đăng xuất", color = Orange) }
            }
            Box(Modifier.weight(1f)) { content() }
        }
        return
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Orange, background = Ink, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF121B31), Ink))).padding(24.dp), contentAlignment = Alignment.Center) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(82.dp).background(Brush.linearGradient(listOf(Orange, Color(0xFFFFB15C))), RoundedCornerShape(25.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.SportsEsports, null, tint = Color.White, modifier = Modifier.size(46.dp)) }
                Text("OMLET REBORN", fontSize = 27.sp, color = Orange, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Text(if (register) "Tạo tài khoản online" else "Chào mừng trở lại", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Dùng email để đăng nhập trên nhiều thiết bị", color = Muted, fontSize = 12.sp)
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, focusedLabelColor = Orange))
                OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Mật khẩu (ít nhất 6 ký tự)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, focusedLabelColor = Orange))
                if (message.isNotBlank()) Text(message, color = if (message.contains("Thành công")) Color(0xFF7BE0A1) else Color(0xFFFF9A83), fontSize = 12.sp)
                Button(onClick = {
                    if (email.isBlank() || password.length < 6) { message = "Nhập email hợp lệ và mật khẩu từ 6 ký tự trở lên."; return@Button }
                    busy = true; message = "Đang kết nối..."
                    scope.launch {
                        val result = if (register) FirebaseAuthApi.register(email, password) else FirebaseAuthApi.login(email, password)
                        busy = false; message = result.message
                        if (result.ok && result.idToken != null) {
                            prefs.edit().putString("email", result.email ?: email).putString("idToken", result.idToken).apply()
                            signedIn = true
                        }
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text(if (busy) "Đang xử lý..." else if (register) "Đăng ký" else "Đăng nhập") }
                TextButton(onClick = { register = !register; message = "" }) { Text(if (register) "Đã có tài khoản? Đăng nhập" else "Chưa có tài khoản? Đăng ký", color = Color(0xFF83BFFF)) }
                Text("Tài khoản được lưu online qua Firebase. Cần cấu hình Firebase trước khi dùng.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun OmletApp() {
    var tab by remember { mutableStateOf("Home") }
    var showOverlayInfo by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var mic by remember { mutableStateOf(true) }
    var selectedRoom by remember { mutableStateOf("Minecraft PE") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Home", "Friends", "Rooms", "Profile").forEach { item ->
                        val icon = when(item) {
                            "Home" -> Icons.Default.Home
                            "Friends" -> Icons.Default.People
                            "Rooms" -> Icons.Default.SportsEsports
                            else -> Icons.Default.Person
                        }
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(icon, contentDescription = item) },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Orange, selectedTextColor = Orange,
                                indicatorColor = Orange.copy(alpha = .14f),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(46.dp).background(
                                Brush.linearGradient(listOf(Orange, Color(0xFFFFB15C))),
                                RoundedCornerShape(15.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.SportsEsports, null, tint = Color.White) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("OMLET REBORN", fontSize = 12.sp, color = Orange, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text(when(tab) { "Home" -> "Game on."; "Friends" -> "Your people."; "Rooms" -> "Find your squad."; else -> "Your profile." },
                                fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        IconButton(onClick = { showOverlayInfo = true }) {
                            Icon(Icons.Default.Layers, "Floating tools", tint = Orange)
                        }
                    }
                }
                when (tab) {
                    "Home" -> {
                        item {
                            Box(Modifier.fillMaxWidth().background(
                                Brush.linearGradient(listOf(Color(0xFF34243B), Color(0xFF20263B))),
                                RoundedCornerShape(24.dp)
                            ).padding(20.dp)) {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("YOUR MOBILE GAMING HUB", color = Color(0xFFFFB18A), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                                    Text("Minecraft PE,\nmade social.", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 33.sp)
                                    Text("Capture moments, meet players and build your next session.", color = Muted)
                                    Button(onClick = { tab = "Rooms" }, colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                                        Icon(Icons.Default.Explore, null); Spacer(Modifier.width(7.dp)); Text("Explore rooms")
                                    }
                                }
                            }
                        }
                        item {
                            Text("QUICK TOOLS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                QuickTile("Screen capture", Icons.Default.Videocam, Modifier.weight(1f)) { recording = !recording }
                                QuickTile("Floating button", Icons.Default.Layers, Modifier.weight(1f)) { showOverlayInfo = true }
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                QuickTile("Voice chat", Icons.Default.Mic, Modifier.weight(1f)) { mic = !mic }
                                QuickTile("Find players", Icons.Default.People, Modifier.weight(1f)) { tab = "Friends" }
                            }
                            if (recording) StatusCard("Capture setup", "Ready to request Android screen-capture permission.", Icons.Default.Videocam)
                            if (!mic) StatusCard("Microphone", "Voice capture is toggled off in this prototype.", Icons.Default.MicOff)
                        }
                        item {
                            Text("FEATURES", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            FeatureRow("Creator studio", "Recording and livestream controls", Icons.Default.LiveTv, "Planned")
                            FeatureRow("Multiplayer rooms", "Find or host a Minecraft session", Icons.Default.Groups, "Preview")
                            FeatureRow("Community feed", "Clips, posts and player profiles", Icons.Default.DynamicFeed, "Planned")
                        }
                    }
                    "Friends" -> {
                        item { StatusCard("Friends & chat", "The screen layout is ready. Real accounts, messaging and presence require a backend service.", Icons.Default.People) }
                        item { FeatureRow("Find players", "Search by username or game interest", Icons.Default.Search, "Preview") }
                        item { FeatureRow("Messages", "Private and group chat", Icons.Default.Chat, "Planned") }
                    }
                    "Rooms" -> {
                        item { Text("GAME ROOMS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }
                        item {
                            listOf("Minecraft PE", "Survival squad", "Creative builders").forEach { room ->
                                Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { selectedRoom = room },
                                    colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Public, null, tint = Orange, modifier = Modifier.size(32.dp))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(room, fontWeight = FontWeight.Bold)
                                            Text(if (room == selectedRoom) "Selected · connection not configured" else "Room preview", color = Muted, fontSize = 12.sp)
                                        }
                                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                    }
                                }
                            }
                        }
                        item { Text("Room cards are demo data. Online play requires a real server or compatible Minecraft world invite.", color = Muted, fontSize = 12.sp) }
                    }
                    else -> {
                        item { StatusCard("Player profile", "A modern profile screen for avatar, bio, game tags and clips. Sign-in is not wired up yet.", Icons.Default.AccountCircle) }
                        item { FeatureRow("Account", "Authentication and profile settings", Icons.Default.ManageAccounts, "Planned") }
                        item { FeatureRow("My clips", "Saved recordings and highlights", Icons.Default.VideoLibrary, "Planned") }
                    }
                }
                item { Text("Prototype v0.1 · No Omlet servers or accounts are connected.", color = Muted, fontSize = 11.sp) }
            }
        }
        if (showOverlayInfo) {
            AlertDialog(
                onDismissRequest = { showOverlayInfo = false },
                title = { Text("Floating game tools") },
                text = { Text("Next implementation step: request Android 'Display over other apps' permission and run a foreground service for the floating button. This prototype shows the design but does not yet draw over Minecraft.") },
                confirmButton = { TextButton(onClick = { showOverlayInfo = false }) { Text("Got it") } },
                containerColor = Panel
            )
        }
    }
}

@Composable
fun QuickTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.height(112.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Orange, modifier = Modifier.size(26.dp))
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
fun StatusCard(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = Orange, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(body, color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun FeatureRow(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector, status: String) {
    Card(Modifier.fillMaxWidth().padding(top = 8.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Orange, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(body, color = Muted, fontSize = 12.sp)
            }
            Text(status, color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}
