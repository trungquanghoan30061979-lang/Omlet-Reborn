# Omlet Reborn — Android MVP starter

This is an early UI prototype and a GitHub Actions workflow to build a **debug APK**.

## Current prototype
- Blue/black Compose UI
- Login/register screens (demo only; no server or persistent account storage)
- Demo Minecraft room list (not real worlds and not connected to Minecraft)
- Android overlay permission flow and floating bubble
- Workflow at `.github/workflows/build-apk.yml`

## Important limitations
- Authentication is not implemented securely; do not use real passwords.
- Room listings are placeholders. No networking, chat backend, live streaming, or Minecraft multiplayer connection exists.
- The floating overlay is a prototype and may need device-specific testing. Android will ask the user to grant overlay permission.
- This debug APK is for testing, not a Play Store release. A Play Store release requires a signed release build, policy/privacy work, testing, and a Play Console developer account.

## Build APK online using GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this folder, keeping the `.github/workflows/build-apk.yml` path intact.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**, then **Run workflow**.
5. When it succeeds, open the run and download `OmletReborn-debug-apk` under Artifacts. Extract the ZIP to get `app-debug.apk`.

The workflow has not been run from this project yet, so successful compilation is not guaranteed until GitHub Actions reports success.
