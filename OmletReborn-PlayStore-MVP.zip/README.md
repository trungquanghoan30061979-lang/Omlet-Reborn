# Omlet Reborn 0.2.0 — online login starter

Android Kotlin/Jetpack Compose source. The login/register screens use Firebase Authentication REST API, which supports the same email account on multiple devices. The APK will NOT authenticate until you configure your own Firebase project.

## Configure Firebase (required, free tier is enough for a prototype)
1. Open https://console.firebase.google.com/ and create a project named Omlet Reborn.
2. In Build → Authentication → Get started → Sign-in method, enable **Email/Password**.
3. Open Project settings → General → Your apps / Web app (create a Web app if needed), and copy the **Web API Key**.
4. In your GitHub repository, open Settings → Secrets and variables → Actions → New repository secret. Name it `FIREBASE_API_KEY` and paste the Web API Key as its value.
5. The workflow passes this secret to Gradle. Do not paste secrets into chat or commit private service-account keys.

## Build on GitHub Actions
The `.github/workflows/build-apk.yml` workflow runs `gradle assembleDebug` and uploads `app-debug.apk` as artifact `OmletReborn-debug-apk`. Download the artifact ZIP and extract it to get the APK.

## Current limits
- Registration/login are online via Firebase after configuration; session is remembered on this device.
- Passwords are sent to Firebase over HTTPS; Firebase manages password storage.
- Username/profile records, chat, livestream, online room listing, Minecraft joining, and actual overlay over other apps are not implemented yet.
- App icon is based on the same gamepad logo displayed above “OMLET REBORN” in the login screen.
- This is a debug build for testing, not a signed Play Store release.
